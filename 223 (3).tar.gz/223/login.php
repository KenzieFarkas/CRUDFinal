<?php
$host = "localhost";
$dbname ="lululemon";
$username = "mfarkas";
$password = "mackenzie";
?>
